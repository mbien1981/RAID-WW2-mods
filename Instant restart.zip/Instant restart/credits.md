This mod edits the same function as [Takku's mod](https://modworkshop.net/mod/20866) in the same way, so credits go to them.
